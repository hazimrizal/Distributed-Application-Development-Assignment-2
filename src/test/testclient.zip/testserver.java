package test;

import java.awt.EventQueue;
import java.io.*;
import java.net.*;

import server.OrderServer;

public class testserver {

	public static void main(String[] args) throws Exception
	{
		ServerSocket c = new ServerSocket(8001);
		Socket cc = c.accept();
		System.out.println("connected");
		DataInputStream din = new DataInputStream(cc.getInputStream());
		@SuppressWarnings("unused")
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		while (true)
		{
			String yoo = din.readUTF();
			
			OrderServer frame = new OrderServer();
			frame.setVisible(true);
			frame.addText(yoo);
			
			System.out.println("client : "+yoo);
				if(yoo.equalsIgnoreCase("exit"))
					break;
		}
		c.close();
		cc.close();
	}

}