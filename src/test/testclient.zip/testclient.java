package test;
import java.io.*;
import java.net.*;


public class testclient {
	public static void main(String[] args) throws Exception
	{
		Socket c = new Socket("localhost",8001);
		DataOutputStream dout = new DataOutputStream(c.getOutputStream());
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		while(true)
		{
			String so = br.readLine();
			dout.writeUTF(so);
			if(so.equalsIgnoreCase("exit"))
				break;
		}
	c.close();
	} 

}
